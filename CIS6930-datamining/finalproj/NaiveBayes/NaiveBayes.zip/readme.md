1. extract the data 
```sh
tar -xvf project_naive_bayes.tar.gz
```
2. install requirements
```sh
sudo pip install -r requirements.txt
```
3. run the code in terminal
```sh
python data_analysis.py
```
All the result will be printed in terminal
4. two figures will be create to show batch-to-bacth train result against train circles

** note: make sure the two data sets we used for this project are in the same directory as the .py files **